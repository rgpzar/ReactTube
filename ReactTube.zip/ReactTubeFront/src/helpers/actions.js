export const actions = {
    CHECK_STORAGE: 1,
    STORE_NEW_SESSION: 2,
    CLEAR_STATE: 3
}