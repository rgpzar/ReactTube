package com.ReactTube.backApplication.models;

public enum Permission {
    READ_AIRPORTS,
    EDIT_AIRPORT,
    DELETE_AIRPORT,
}
