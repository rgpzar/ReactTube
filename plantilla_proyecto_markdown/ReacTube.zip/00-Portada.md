---
title: "ReactTube - Plataforma web de video"
author: [Raul Granados Pacheco]
date: "Diciembre 2023"
keywords: [computación, programación, backend, frontend, ciberseguridad, jwt, springboot, reactjs]
lang: "es"
titlepage: true
titlepage-text-color: "FFFFFF"
titlepage-rule-color: "360049"
titlepage-rule-height: 0
titlepage-background: "docs/background.pdf"
toc: false
---

\pagebreak
\tableofcontents
\pagebreak
